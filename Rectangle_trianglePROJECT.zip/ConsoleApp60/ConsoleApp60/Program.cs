﻿using System;
public class Exercise61
{
    public static void Main()
    {
        int row, column;

        Console.Write("\n\n");
        Console.Write("pravokotnik in trikotniki(lik)");
        Console.Write("---------------------------------------------");
        Console.Write("\n\n");
        Console.BackgroundColor = ConsoleColor.Gray;
        Console.ForegroundColor = ConsoleColor.Black;
        

        for (row = 0; row <= 40; row++)
        {
            for (column = 0; column <=40; column++)
            {
                Console.Write(" ");
                Console.Write(" ");
                Console.Write(" ");
                Console.Write(" ");
                if (column == 1 || ((row == 0 || row == 40) && (column > 1 && column < 40)) || (column == 30 && row != 0 && row != 40))
            
                    Console.Write("*");
                else if(column == 1 || ((row == 0 || row == 15) && (column > 1 && column < 15)) || (column == 15 && row != 0 && row != 15))
                {
                    Console.Write("");
                }
                  else if(column == 1 || ((row == 0 || row == 13) && (column > 1 && column < 13)) || (column == 13 && row != 0 && row != 13))
                {
                    Console.Write("/");
                }
                else if (column == 2 || ((row == 5 || row == 16) && (column > 1 && column < 16)) || (column == 16 && row != 0 && row != 16))
                {
                    Console.Write("#");
                }
                else if (column == 2 || ((row == 4 || row == 15) && (column > 1 && column < 15)) || (column == 15 && row != 0 && row != 15))
                {
                    Console.Write("C#!");
                    
                }
                else if (column == 2 || ((row == 4 || row == 15) && (column > 1 && column < 15)) || (column == 15 && row != 0 && row != 15))
                {
                    Console.Write("C#!");


                }
                else
             
                    Console.Write(" ");
            }
            Console.Write("\n");

        }
        
        int k = 1;
        for (int x = 1; x <= row; x++)
        {
            for (int y = 1; y <= x; y++)
            {
                Console.Write("@", k++);
                Console.Write(" ");
                Console.Write(" ");
                Console.Write(" ");
                Console.Write(" ");
                Console.Write(" ");
                Console.Write(" ");

            }
               
                 
            Console.Write("\n");
        }

        int i, j;
        int r = 30;
        
        for (int z = 0; z <= r; z++)
        {
            for (j = 1; j <= r - z; j++)
                Console.Write(" ");
            for (j = 1; j <= 2 * z - 1; j++)
                Console.Write("();");
            Console.Write("\n");
        }


        for (i = r - 1; i >= 1; i--)
        {
            for (j = 1; j <= r - i; j++)
                Console.Write(" ");
            for (j = 1; j <= 4 * i - 1; j++)
                Console.Write("$$");
            Console.Write("\n");
        }

        for (int z = 0; z <= r; z++)
        {
            for (j = 1; j <= r - z; j++)
                Console.Write("    ");
            for (j = 1; j <= 2 * z - 1; j++)
                Console.Write("X");
            Console.Write("\n");
        }


        for (i = r - 1; i >= 1; i--)
        {
            for (j = 1; j <= r - i; j++)
                Console.Write(" ");
            for (j = 1; j <= 6 * i - 1; j++)
                Console.Write("O");
           
            Console.Write("\n");
        }


    }
}